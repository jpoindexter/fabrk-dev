<template>
  <slot />
</template>
