<script lang="ts" setup>
  import { toValue } from "vue";
  import { useFormField } from "./useFormField";

  const { name, formMessageId } = useFormField();
</script>

<template>
  <ErrorMessage
    :id="formMessageId"
    as="p"
    :name="toValue(name)"
    class="text-destructive text-sm font-normal"
  />
</template>
